# NaowhUI_Data

## [20260117.01](https://github.com/rootkit1337tv/NaowhUI_Data/tree/20260117.01) (2026-01-17)
[Full Changelog](https://github.com/rootkit1337tv/NaowhUI_Data/compare/20260106.01...20260117.01) [Previous Releases](https://github.com/rootkit1337tv/NaowhUI_Data/releases)

## Class WA's Classic and TBC

### TBC

**Overall**
- Fixed issue that MP5 was not showing.

**Warrior** 
- Fixed Aura Bar not showing
- Fixed Commanding Shout and Battle Shout reminder

**Paladin**
- Changed Swing Timer bar to include Seal Twist stuff.
- Added Vengeance tracking to Aura Bar

**Druid**
- Fixed double tick showing. 
- Changed Lacerate to target debuff.

**Priest**
- Added Vampiric Touch to Aura Bar
- Moved Shadow Word: Pain, Holy Fire to Aura Bar

### Classic

**Overall**
- Added back MP5 and energy ticks.


Think that's all for now, if I missed anything just lmk in the correct feedback channels. 

These changes are in the updated addon which you can download from here: https://naowhui.howli.gg/

Happy gaming <:peepoGamer:706663445751267398>
